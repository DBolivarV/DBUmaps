#'DBUmaps Package
#'
#'
#'Contiene Funcion que grafica mapas dinamicos con las caracteristicas de los suelos
#'
#'@docType package
#'
#'@author Diego Bolivar \email{diego.bolivar@unet.edu.ve}
#'
#'@name package1
NULL
